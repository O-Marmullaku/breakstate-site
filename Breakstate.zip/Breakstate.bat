@echo off
setlocal
set "game=%~dp0Breakstate.exe"
if not exist "%game%" set "game=%~dp0Builds\Windows\Breakstate.exe"
if not exist "%game%" (
    echo Breakstate.exe is missing. Run this launcher beside a Windows build or from a checkout with Builds\Windows\Breakstate.exe.
    exit /b 1
)
for %%I in ("%game%") do set "gameDir=%%~dpI"

echo 1 Play Breakstate ^(normal game, frontend^)
echo 2 Dev: test map, 1 instance
echo 3 Dev: test map, 2 instances connected
echo 4 Normal rounds, 2 instances connected
echo Q Quit
choice /c 1234Q /n /m "Choose 1, 2, 3, 4 or Q: "
if errorlevel 255 exit /b 1
if errorlevel 5 exit /b 0
if errorlevel 4 goto normal_pair
if errorlevel 3 goto dev_pair
if errorlevel 2 goto dev_solo
if not errorlevel 1 exit /b 1
start "" /d "%gameDir%" "%game%"
exit /b

:dev_solo
call :instance 1 lab -breakstate-dev-round
exit /b

:dev_pair
call :instance 1 lab -breakstate-dev-round
call :instance 2 lab -breakstate-dev-round
exit /b

:normal_pair
call :instance 1 1v1
call :instance 2 1v1
exit /b

:instance
start "" /d "%gameDir%" "%game%" -breakstate-instance %1 -map lab -mode %2 %3 -screen-fullscreen 0 -screen-width 960 -screen-height 540 -logFile "%TEMP%\Breakstate-instance-%1.log"
exit /b
