[CmdletBinding()]
param(
    # menu = the interactive numbered menu; the others run one entry and return (used by the contract test).
    [ValidateSet("menu", "one", "two", "stop")]
    [string]$Action = "menu",
    # Defaults to Breakstate.exe beside this script.
    [string]$ExecutablePath = "",
    # Window size in pixels; 0 = derive from the primary screen (one copy 1280x720, two copies left/right halves).
    [int]$WindowWidth = 0,
    [int]$WindowHeight = 0,
    # Where the PIDs of the copies this menu started are kept (stop-all touches nothing else).
    [string]$StateFile = "",
    [string]$LogRoot = "",
    [ValidateSet("lab", "1v1", "2v2")]
    [string]$Mode = "1v1",
    [int]$TimeoutSeconds = 90
)

# Developer menu shipped beside Breakstate.exe: start one copy, or two copies of the same session (one host, one client,
# auto-connected) side by side, and stop the copies it started. Needs only Windows PowerShell 5.1. The launch logic is
# breakstate-instances.ps1 next to this file (the repo launcher tools/multiplayer/start-two-menu-instances.ps1 shares it).

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Shipped: beside this file. In the repo: tools/multiplayer.
$instances = Join-Path $PSScriptRoot "breakstate-instances.ps1"
if (-not (Test-Path -LiteralPath $instances)) { $instances = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot "..\..\multiplayer\breakstate-instances.ps1")) }
. $instances

if (-not $ExecutablePath) { $ExecutablePath = Join-Path $PSScriptRoot "Breakstate.exe" }
if (-not $StateFile) { $StateFile = Join-Path $env:TEMP "BreakstateDevMenu\started-processes.txt" }
if (-not $LogRoot) { $LogRoot = Join-Path $env:TEMP "BreakstateDevMenu\logs" }

# One line per started copy: pid|start-time ticks|session. The start time guards against a reused PID.
function Get-OwnedProcesses {
    if (-not (Test-Path -LiteralPath $StateFile)) { return @() }
    $owned = @()
    foreach ($line in @(Get-Content -LiteralPath $StateFile)) {
        $parts = $line -split '\|'
        if ($parts.Count -lt 2) { continue }
        $process = Get-Process -Id ([int]$parts[0]) -ErrorAction SilentlyContinue
        if ($process -and $process.StartTime.ToUniversalTime().Ticks -eq [int64]$parts[1]) { $owned += $process }
    }
    return $owned
}

function Save-OwnedProcesses {
    param([System.Diagnostics.Process[]]$Processes, [string]$Session = "")
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $StateFile) | Out-Null
    $lines = @(Get-OwnedProcesses | ForEach-Object { "$($_.Id)|$($_.StartTime.ToUniversalTime().Ticks)|" })
    foreach ($process in $Processes) { $lines += "$($process.Id)|$($process.StartTime.ToUniversalTime().Ticks)|$Session" }
    Set-Content -LiteralPath $StateFile -Value ($lines | Select-Object -Unique) -Encoding ASCII
}

function Stop-OwnedProcesses {
    $owned = @(Get-OwnedProcesses)
    foreach ($process in $owned) {
        try { Stop-Process -Id $process.Id -Force } catch { }
    }
    if (Test-Path -LiteralPath $StateFile) { Remove-Item -LiteralPath $StateFile -Force }
    Write-Host "Stopped $($owned.Count) copy(ies) started by this menu."
}

function Assert-Executable {
    if (-not (Test-Path -LiteralPath $ExecutablePath -PathType Leaf)) { throw "Game not found: $ExecutablePath" }
}

function Start-OneCopy {
    Assert-Executable
    $width = if ($WindowWidth -gt 0) { $WindowWidth } else { 1280 }
    $height = if ($WindowHeight -gt 0) { $WindowHeight } else { 720 }
    $runLog = Join-Path $LogRoot ((Get-Date -Format "yyyyMMdd-HHmmss") + "-" + [guid]::NewGuid().ToString("N").Substring(0, 6))
    New-Item -ItemType Directory -Force -Path $runLog | Out-Null
    $log = Join-Path $runLog "instance-1.log"
    $process = Start-BreakstateInstance -ProgramPath $ExecutablePath -LogPath $log -WindowWidth $width -WindowHeight $height `
        -PlayerKey (New-BreakstatePlayerKey)
    Save-OwnedProcesses -Processes @($process)
    Write-Host "Started one copy (PID $($process.Id)); log $log"
}

function Start-TwoCopies {
    Assert-Executable
    $width = $WindowWidth
    $height = $WindowHeight
    if ($width -le 0 -or $height -le 0) {
        $area = Get-BreakstatePrimaryWorkArea
        $width = [int][Math]::Floor($area.Width / 2)
        $height = $area.Height
    }
    $session = New-BreakstateSessionName
    $runLog = Join-Path $LogRoot $session
    New-Item -ItemType Directory -Force -Path $runLog | Out-Null
    $hostLog = Join-Path $runLog "instance-1.log"
    $clientLog = Join-Path $runLog "instance-2.log"
    $started = @()
    try {
        $hostProcess = Start-BreakstateInstance -ProgramPath $ExecutablePath -LogPath $hostLog -WindowWidth $width -WindowHeight $height `
            -Role host -SessionName $session -Mode $Mode -PlayerKey (New-BreakstatePlayerKey)
        $started += $hostProcess
        Save-OwnedProcesses -Processes @($hostProcess) -Session $session
        Wait-BreakstateSessionStarted -Process $hostProcess -LogPath $hostLog -Role Host -SessionName $session -Mode $Mode -TimeoutSeconds $TimeoutSeconds
        $clientProcess = Start-BreakstateInstance -ProgramPath $ExecutablePath -LogPath $clientLog -WindowWidth $width -WindowHeight $height `
            -Role client -SessionName $session -Mode $Mode -PlayerKey (New-BreakstatePlayerKey)
        $started += $clientProcess
        Save-OwnedProcesses -Processes @($clientProcess) -Session $session
        Wait-BreakstateSessionStarted -Process $clientProcess -LogPath $clientLog -Role Client -SessionName $session -Mode $Mode -TimeoutSeconds $TimeoutSeconds
        if ([IO.Path]::GetExtension($ExecutablePath) -ine ".ps1") {
            Set-BreakstateSideBySideWindows -Processes @($hostProcess, $clientProcess) -TimeoutSeconds $TimeoutSeconds
        }
    }
    catch {
        foreach ($process in $started) { try { Stop-Process -Id $process.Id -Force } catch { } }
        throw
    }
    Write-Host "Started two copies in session ${session}: host PID $($hostProcess.Id), client PID $($clientProcess.Id); logs in $runLog"
}

function Invoke-Safely([scriptblock]$Body) {
    try { & $Body } catch { Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red }
}

switch ($Action) {
    "one" { Start-OneCopy }
    "two" { Start-TwoCopies }
    "stop" { Stop-OwnedProcesses }
    "menu" {
        while ($true) {
            Write-Host ""
            Write-Host "Breakstate dev menu"
            Write-Host "  1  Start one copy"
            Write-Host "  2  Start two local copies (host + client, same session, side by side)"
            Write-Host "  3  Stop all copies started by this menu"
            Write-Host "  4  Quit"
            $choice = (Read-Host "Choose 1-4").Trim()
            switch ($choice) {
                "1" { Invoke-Safely { Start-OneCopy } }
                "2" { Invoke-Safely { Start-TwoCopies } }
                "3" { Invoke-Safely { Stop-OwnedProcesses } }
                "4" { return }
                default { Write-Host "Please type 1, 2, 3 or 4." }
            }
        }
    }
}
