# Shared by the repo launcher (start-two-menu-instances.ps1) and the shipped dev menu (tools/release/dev-menu): starting
# game copies with window, session and player-key arguments, waiting until a session is up, and tiling two windows.
# Dot-source this file; it defines functions only and needs nothing but Windows PowerShell 5.1 (no git, no repo).

function Quote-ProcessArgument {
    param([string]$Value)

    if ($Value -notmatch '[\s"]') {
        return $Value
    }

    return '"' + ($Value -replace '(\\*)"', '$1$1\"' -replace '(\\+)$', '$1$1') + '"'
}

# A key the game accepts (SessionPlayerKey: 1-64 letters, digits, '-' or '_'); distinct per call.
function New-BreakstatePlayerKey {
    return "dev-" + [guid]::NewGuid().ToString("N")
}

function New-BreakstateSessionName {
    return "BreakstatePlay-" + [guid]::NewGuid().ToString("N")
}

# Starts one copy of the game and returns its process. Role (host|client) with SessionName/Mode auto-connects it;
# without a role the copy opens at its menu. PlayerKey keeps two copies on one PC from sharing an identity.
function Start-BreakstateInstance {
    param(
        [Parameter(Mandatory)][string]$ProgramPath,
        [Parameter(Mandatory)][string]$LogPath,
        [Parameter(Mandatory)][int]$WindowWidth,
        [Parameter(Mandatory)][int]$WindowHeight,
        [string]$Role = "",
        [string]$SessionName = "",
        [string]$Mode = "1v1",
        [string]$Character = "",
        [string]$PlayerKey = ""
    )

    $gameArguments = @(
        "-screen-fullscreen", "0",
        "-screen-width", $WindowWidth.ToString(),
        "-screen-height", $WindowHeight.ToString(),
        "-logFile", $LogPath,
        "-breakstate-diagnostics",
        # Keeps the developer Host/Client panel visible over the frontend (F1 toggles it).
        "-breakstate-dev-menu"
    )
    if ($PlayerKey) {
        $gameArguments += @("-breakstate-player-key", $PlayerKey)
    }
    if ($Character) {
        $gameArguments += @("-breakstate-character", $Character)
    }
    if ($Role) {
        $gameArguments += @("-session", $SessionName, "-role", $Role, "-mode", $Mode)
    }

    if ([System.IO.Path]::GetExtension($ProgramPath) -ieq ".ps1") {
        $powerShellPath = (Get-Command powershell.exe -ErrorAction Stop).Source
        $processArguments = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $ProgramPath) + $gameArguments
        $quotedArguments = $processArguments | ForEach-Object { Quote-ProcessArgument -Value $_ }
        return Start-Process -FilePath $powerShellPath -ArgumentList $quotedArguments -WindowStyle Hidden -PassThru
    }

    $quotedGameArguments = $gameArguments | ForEach-Object { Quote-ProcessArgument -Value $_ }
    return Start-Process `
        -FilePath $ProgramPath `
        -ArgumentList $quotedGameArguments `
        -WorkingDirectory (Split-Path -Parent $ProgramPath) `
        -WindowStyle Normal `
        -PassThru
}

function Wait-BreakstateSessionStarted {
    param(
        [System.Diagnostics.Process]$Process,
        [string]$LogPath,
        [string]$Role,
        [string]$SessionName,
        [string]$Mode,
        [int]$TimeoutSeconds = 60
    )

    $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
    $readyPattern = '^BREAKSTATE_SESSION_STARTED role=' + $Role + ' session=' + [regex]::Escape($SessionName) + '$'
    # StartGame can finish before the starting scene and host player are ready.
    # Give the client a live gameplay host, rather than a room still loading.
    $hostPlayerPattern = '^BREAKSTATE_PLAYER_SPAWNED player=\d+ role=Host slot=0 mode=' + [regex]::Escape($Mode) + '$'
    while ([DateTime]::UtcNow -lt $deadline) {
        if (Test-Path -LiteralPath $LogPath -PathType Leaf) {
            $logText = ''
            try {
                $stream = [IO.File]::Open($LogPath, [IO.FileMode]::Open, [IO.FileAccess]::Read,
                    [IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete)
                $reader = [IO.StreamReader]::new($stream)
                try { $logText = $reader.ReadToEnd().Replace("`r", '') }
                finally { $reader.Dispose() }
            }
            catch [IO.IOException] {
                # The writer may briefly hold an exclusive handle; poll again.
            }
            if ($logText -match '(?m)^BREAKSTATE_SESSION_(FAILED|ARGUMENTS_FAILED|BOOTSTRAP_FAILED)\b') {
                throw "$Role failed to start; inspect $LogPath"
            }
            if ($logText -match ('(?m)' + $readyPattern) -and
                ($Role -ne 'Host' -or $logText -match ('(?m)' + $hostPlayerPattern))) { return }
        }
        $Process.Refresh()
        if ($Process.HasExited) { throw "$Role exited during startup; inspect $LogPath" }
        Start-Sleep -Milliseconds 250
    }
    throw "$Role readiness timed out after $TimeoutSeconds seconds; inspect $LogPath"
}

# The window rectangle of copy $Index of $Count on a work area: equal vertical slices, the last takes the remainder.
function Get-BreakstateTileBounds {
    param([int]$Left, [int]$Top, [int]$Width, [int]$Height, [int]$Index, [int]$Count = 2)

    $slice = [int][Math]::Floor($Width / $Count)
    $x = $Left + $Index * $slice
    $w = if ($Index -eq $Count - 1) { $Width - $slice * ($Count - 1) } else { $slice }
    return [pscustomobject]@{ X = $x; Y = $Top; Width = $w; Height = $Height }
}

# Primary screen work area in physical pixels.
function Get-BreakstatePrimaryWorkArea {
    Add-Type -AssemblyName System.Windows.Forms
    if (-not ('BreakstateMenuWindows' -as [type])) {
        Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class BreakstateMenuWindows {
    [StructLayout(LayoutKind.Sequential)] public struct Rect { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr window, out Rect rect);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr window, IntPtr after, int x, int y, int width, int height, uint flags);
}
"@
    }
    $previousDpi = [BreakstateMenuWindows]::SetThreadDpiAwarenessContext([IntPtr](-4))
    try { return [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea }
    finally { [void][BreakstateMenuWindows]::SetThreadDpiAwarenessContext($previousDpi) }
}

function Set-BreakstateSideBySideWindows {
    param([System.Diagnostics.Process[]]$Processes, [int]$TimeoutSeconds = 60)

    $area = Get-BreakstatePrimaryWorkArea
    $previousDpi = [BreakstateMenuWindows]::SetThreadDpiAwarenessContext([IntPtr](-4))
    try {
        $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
        $stableSince = [DateTime]::UtcNow
        while ([DateTime]::UtcNow -lt $deadline) {
            $aligned = $true
            for ($i = 0; $i -lt $Processes.Count; $i++) {
                $process = $Processes[$i]
                $process.Refresh()
                if ($process.HasExited) { throw 'A gameplay window exited before placement completed.' }
                $window = $process.MainWindowHandle
                if ($window -eq [IntPtr]::Zero) { $aligned = $false; continue }
                $tile = Get-BreakstateTileBounds -Left $area.Left -Top $area.Top -Width $area.Width -Height $area.Height -Index $i -Count $Processes.Count
                $rect = New-Object BreakstateMenuWindows+Rect
                if (-not [BreakstateMenuWindows]::GetWindowRect($window, [ref]$rect)) { Write-Warning 'Cannot read gameplay window bounds; leaving windows where they are.'; return }
                if ($rect.Left -ne $tile.X -or $rect.Top -ne $tile.Y -or
                    $rect.Right -ne ($tile.X + $tile.Width) -or $rect.Bottom -ne ($tile.Y + $tile.Height)) {
                    $aligned = $false
                    # Unity applies saved display settings after its splash; reapply until those changes settle.
                    if (-not [BreakstateMenuWindows]::SetWindowPos($window, [IntPtr]::Zero, $tile.X, $tile.Y, $tile.Width, $tile.Height, 0x0014)) {
                        Write-Warning 'Cannot place gameplay window; leaving windows where they are.'; return
                    }
                }
            }
            if (-not $aligned) { $stableSince = [DateTime]::UtcNow }
            if ($aligned -and ([DateTime]::UtcNow - $stableSince).TotalSeconds -ge 5) {
                Write-Host "Gameplay windows verified side by side on primary monitor: $($area.Width)x$($area.Height)."
                return
            }
            Start-Sleep -Milliseconds 250
        }
        # Placement is cosmetic: a connected session stays up for the tester even if the windows never settle.
        Write-Warning 'Gameplay windows did not settle into their left/right halves; leaving the session running.'
    }
    finally { [void][BreakstateMenuWindows]::SetThreadDpiAwarenessContext($previousDpi) }
}
