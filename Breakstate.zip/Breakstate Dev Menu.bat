@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Breakstate Dev Menu.ps1"
if errorlevel 1 (
  echo.
  echo The Breakstate dev menu stopped with an error. See above.
  pause
  exit /b 1
)
endlocal
